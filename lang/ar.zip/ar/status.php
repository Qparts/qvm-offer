<?php

return [
    'success'                           => 'نجح',
    'failure'                           => 'فشل',
    'deposit'                           => 'إيداع',
    'withdraw'                          => 'سحب',

];
