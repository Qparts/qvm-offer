<?php

return [
    'page_not_found'                    => 'الصفحة غير موجودة.',
    'wallet_charged'                    => 'تم شحن محفظتك بنجاح.',
    'balance_not_enough'                => 'رصيد المحفظة غير كافٍ للشراء.',
    'purchased_successfully'            => 'تم الشراء بنجاح.',

];
