<?php

return [
    'amount'                            => 'المبلغ',

];
